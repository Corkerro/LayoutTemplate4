<?
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

	require 'phpmailer/src/Exception.php';
	require 'phpmailer/src/PHPMailer.php';
	require 'phpmailer/src/SMTP.php';

	$mail = new PHPMailer(true);
	$mail->CharSet = 'UTF-8';
	$mail->setLanguage('uk', 'phpmailer/language/');
	$mail->IsHTML(true);

	$mail->isSMTP(); //Send using SMTP
	$mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
	$mail->SMTPAuth = true; //Enable SMTP authentication
	$mail->Username = 'codeonlybox@gmail.com'; //SMTP username (email)
	
	// Google Account -> Security -> App passwords -> Add
	$mail->Password = ''; // SMTP password (App password)

	$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
	$mail->Port = 465;
?>